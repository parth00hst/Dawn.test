# ✅ GitHub-compatible Dawn Auto-Login Script (Without GUI or Extension)
# 📌 NOTE: This script ONLY logs in via HTTP POST (no browser or extension)
# 🔐 CAPTCHA must be manually solved or disabled for it to work fully

import requests
import json

# ✅ Replace these with your actual credentials
EMAIL = "parthjethva89@gmail.com"
PASSWORD = "@Parth00hst"

# Dawn login URL (assumed)
LOGIN_URL = "https://dashboard.dawninternet.com/api/v1/auth/login"

# Optional: Save headers or session for later use
headers = {
    "Content-Type": "application/json",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
}

payload = {
    "email": EMAIL,
    "password": PASSWORD
    # CAPTCHA required field might go here (e.g., "captcha": "..."), but skipped for now
}

print("[+] Sending login request to Dawn...")
response = requests.post(LOGIN_URL, headers=headers, json=payload)

if response.status_code == 200:
    try:
        data = response.json()
        print("[✅] Login Success")
        print(json.dumps(data, indent=2))

        # Save token (if exists)
        if 'token' in data:
            with open("auth_token.json", "w") as f:
                json.dump({"token": data['token']}, f)
            print("[💾] Auth token saved to auth_token.json")

    except Exception as e:
        print("[❌] Error parsing response:", e)
else:
    print(f"[❌] Login failed with status {response.status_code}")
    print(response.text)
